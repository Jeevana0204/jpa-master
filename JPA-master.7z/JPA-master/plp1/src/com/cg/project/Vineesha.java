package com.cg.project;

public class Vineesha {
	public static void main(String args[])
	{
System.out.println("Vineesha");
	}
}
